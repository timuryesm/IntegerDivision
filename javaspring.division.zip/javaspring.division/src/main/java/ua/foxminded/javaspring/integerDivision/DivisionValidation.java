package ua.foxminded.javaspring.integerDivision;

public class DivisionValidation {

    public static boolean isValidDivision(int dividend, int divisor) {
        return divisor != 0;
    }
}
